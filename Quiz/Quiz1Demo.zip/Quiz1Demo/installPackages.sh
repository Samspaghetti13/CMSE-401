pip install --user numpy
pip install --user scipy
pip install --user matplotlib
pip install --user dill
pip install --user scikit-learn
pip install --user sympy
